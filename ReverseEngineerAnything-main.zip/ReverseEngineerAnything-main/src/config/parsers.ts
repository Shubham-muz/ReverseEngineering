import { z } from "zod";
import { isAbsolute } from "node:path";

import { ConfigurationError } from "../domain/errors.js";
import { err, ok, type Result } from "../domain/result.js";

export const parseStringArray = (
  encoded: string,
  name: string,
): Result<readonly string[], ConfigurationError> => {
  try {
    const parsed = z.array(z.string().min(1)).safeParse(JSON.parse(encoded));
    return parsed.success
      ? ok(parsed.data)
      : err(
          new ConfigurationError(`${name} must encode an array of strings`, {
            cause: parsed.error,
          }),
        );
  } catch (cause: unknown) {
    return err(new ConfigurationError(`${name} must be valid JSON`, { cause }));
  }
};

/** Parse a JSON string array whose members must all be absolute paths. */
export const parseAbsoluteRoots = (
  encoded: string,
  name: string,
): Result<readonly string[], ConfigurationError> => {
  const parsed = parseStringArray(encoded, name);
  if (!parsed.ok) return parsed;
  return parsed.value.some((root) => !isAbsolute(root))
    ? err(new ConfigurationError(`${name} must encode absolute roots`))
    : parsed;
};

export const parseBrowserArray = (
  encoded: string,
  name: string,
  itemSchema: z.ZodType<string>,
): Result<readonly string[], ConfigurationError> => {
  try {
    const parsed = z.array(itemSchema).safeParse(JSON.parse(encoded));
    return parsed.success
      ? ok([...new Set(parsed.data)].sort())
      : err(
          new ConfigurationError(`${name} must encode valid browser scopes`, {
            cause: parsed.error,
          }),
        );
  } catch (cause: unknown) {
    return err(new ConfigurationError(`${name} must be valid JSON`, { cause }));
  }
};

export const parseLoaderArgs = (
  encoded: string | undefined,
): Result<readonly string[], ConfigurationError> => {
  if (encoded === undefined) return ok([]);
  let decoded: unknown;
  try {
    decoded = JSON.parse(encoded);
  } catch (cause: unknown) {
    return err(
      new ConfigurationError("HOPPER_LOADER_ARGS_JSON must be valid JSON", {
        cause,
      }),
    );
  }
  const parsed = z.array(z.string()).safeParse(decoded);
  return parsed.success
    ? ok(parsed.data)
    : err(
        new ConfigurationError(
          "HOPPER_LOADER_ARGS_JSON must encode an array of strings",
          { cause: parsed.error },
        ),
      );
};
